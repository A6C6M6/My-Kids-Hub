document.addEventListener("DOMContentLoaded", async () => {
    const form = document.getElementById("passwordResetForm");
    const newPassword = document.getElementById("newPassword");
    const confirmPassword = document.getElementById("confirmPassword");
    const updateBtn = document.getElementById("updatePasswordBtn");
    const message = document.getElementById("passwordResetMessage");

    if (!form || !newPassword || !confirmPassword || !updateBtn || !message) return;

    const showMessage = (text, type) => {
        message.hidden = false;
        message.textContent = text;
        message.className = `reset-message ${type}`;
    };

    const togglePassword = (input, icon) => {
        if (!input || !icon) return;
        icon.addEventListener("click", () => {
            const isPassword = input.type === "password";
            input.type = isPassword ? "text" : "password";
            icon.classList.toggle("fa-eye", !isPassword);
            icon.classList.toggle("fa-eye-slash", isPassword);
        });
    };

    togglePassword(newPassword, document.getElementById("toggleNewPassword"));
    togglePassword(confirmPassword, document.getElementById("toggleConfirmPassword"));

    if (!window.supabaseClient || !window.supabaseClient.auth) {
        showMessage("Authentication service is not available. Please try again later.", "error");
        updateBtn.disabled = true;
        return;
    }

    try {
        const { data, error } = await window.supabaseClient.auth.getSession();
        if (error || !data?.session) {
            showMessage("This password reset link is invalid or has expired. Please request a new reset link.", "error");
            updateBtn.disabled = true;
            return;
        }
    } catch (error) {
        console.error("My Kids Hub Password Reset Session Error:", error);
        showMessage("Unable to verify the password reset session. Please request a new reset link.", "error");
        updateBtn.disabled = true;
        return;
    }

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        message.hidden = true;

        const password = newPassword.value;
        const confirmation = confirmPassword.value;

        if (password.length < 6) {
            showMessage("Password must be at least 6 characters.", "error");
            newPassword.focus();
            return;
        }

        if (password !== confirmation) {
            showMessage("Passwords do not match.", "error");
            confirmPassword.focus();
            return;
        }

        const originalContent = updateBtn.innerHTML;
        updateBtn.disabled = true;
        updateBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';

        try {
            const { error } = await window.supabaseClient.auth.updateUser({ password });
            if (error) throw error;

            showMessage("Password updated successfully. You can now log in with your new password.", "success");
            form.reset();

            setTimeout(async () => {
                try {
                    await window.supabaseClient.auth.signOut();
                } catch (signOutError) {
                    console.warn("My Kids Hub Sign Out Warning:", signOutError);
                }
                window.location.href = "index.html";
            }, 1800);
        } catch (error) {
            console.error("My Kids Hub Password Update Error:", error);
            showMessage(error?.message || "Unable to update password. Please try again.", "error");
            updateBtn.disabled = false;
            updateBtn.innerHTML = originalContent;
        }
    });
});
